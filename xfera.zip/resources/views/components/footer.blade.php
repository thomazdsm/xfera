<footer class="footer">
    <div class="container">
        <nav class="pull-left">
            <ul>
                <li>
                    <a href="#">
                        Home
                    </a>
                </li>
                <li>
                    <a href="#">
                        Company
                    </a>
                </li>
                <li>
                    <a href="#">
                        Portfolio
                    </a>
                </li>
                <li>
                    <a href="#">
                        Blog
                    </a>
                </li>
            </ul>
        </nav>
        <div class="social-area pull-right">
            <a class="btn btn-social btn-facebook btn-simple" href="#" target="_blank">
                <i class="fa fa-facebook-square"></i>
            </a>
            <a class="btn btn-social btn-instagram btn-simple" href="#" target="_blank">
                <i class="fa fa-instagram"></i>
            </a>
            <a class="btn btn-social btn-github btn-simple" href="#" target="_blank">
                <i class="fa fa-github"></i>
            </a>
        </div>
        <div class="copyright">
            Copyright &copy; 2023 <a href="#">XFera Tech</a>. Todos os direitos reservados
        </div>
    </div>
</footer>
