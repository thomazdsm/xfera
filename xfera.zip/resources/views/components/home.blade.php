<div class="parallax filter-gradient full-xfera" data-color="blue">
    <div class="parallax-background bg-xfera">
{{--        <img class="parallax-background-image" src="{{ asset('img/template/bg3.jpg') }}"  alt="Template Background"/>--}}
    </div>
    <div class="container teste" style="">
        <div class="row">
            <div class="col-md-12">
                <h1 class="xfera-presentation-title text-center">XFERA TECH</h1>
            </div>
            <div class="col-md-12">
                <h2 class="xfera-presentation-subtitle text-center">Soluções tecnológicas para educação e pesquisa</h2>
            </div>
        </div>
    </div>
</div>
