<!-- Navbar -->
{{--<nav class="navbar navbar-expand-lg transparent navbar-transparent navbar-light navbar-clone fixed navbar-unstick">--}}
{{--    <div class="container px-3">--}}
{{--        <a class="navbar-brand" href="https://block.codescandy.com/index.html">--}}
{{--            <img src="{{ asset('img/logo.svg') }}" alt="">--}}
{{--        </a>--}}
{{--        <button class="navbar-toggler offcanvas-nav-btn" type="button">--}}
{{--            <i class="bi bi-list"></i>--}}
{{--        </button>--}}
{{--        <div class="offcanvas offcanvas-start offcanvas-nav" style="width: 20rem">--}}
{{--            <div class="offcanvas-header">--}}
{{--                <a href="https://block.codescandy.com/index.html" class="text-inverse"><img src="{{ asset('img/logo.svg') }}" alt=""></a>--}}
{{--                <button type="button" class="btn-close" data-bs-dismiss="offcanvas" aria-label="Close"></button>--}}
{{--            </div>--}}
{{--            <div class="offcanvas-body pt-0 align-items-center">--}}
{{--                <ul class="navbar-nav mx-auto align-items-lg-center">--}}
{{--                    <li class="nav-item dropdown">--}}
{{--                        <a class="nav-link dropdown-toggle" href="https://block.codescandy.com/landing-finance.html#" role="button" data-bs-toggle="dropdown" aria-expanded="false">Landings</a>--}}
{{--                        <ul class="dropdown-menu">--}}
{{--                            <li><a class="dropdown-item" href="https://block.codescandy.com/index.html">Landing Overview</a></li>--}}
{{--                            <li><a class="dropdown-item" href="https://block.codescandy.com/landing-sass-v1.html">Saas v.1</a></li>--}}
{{--                            <li><a class="dropdown-item" href="https://block.codescandy.com/landing-sass-v2.html">Sass v.2</a></li>--}}
{{--                            <li><a class="dropdown-item" href="https://block.codescandy.com/landing-accounting.html">Accounting</a></li>--}}
{{--                            <li><a class="dropdown-item" href="https://block.codescandy.com/landing-finance.html">Finance</a></li>--}}
{{--                            <li><a class="dropdown-item" href="https://block.codescandy.com/landing-jamstack-agancy.html">Jamstack Agency</a></li>--}}
{{--                            <li><a class="dropdown-item" href="https://block.codescandy.com/landing-conference.html">Conference</a></li>--}}
{{--                            <li><a class="dropdown-item" href="https://block.codescandy.com/landing-personal.html">Personal</a></li>--}}
{{--                        </ul>--}}
{{--                    </li>--}}
{{--                    <li class="nav-item dropdown">--}}
{{--                        <a class="nav-link dropdown-toggle" href="https://block.codescandy.com/landing-finance.html#" role="button" data-bs-toggle="dropdown" aria-expanded="false">Pages</a>--}}
{{--                        <div class="dropdown-menu dropdown-menu-xxl">--}}
{{--                            <div class="row row-cols-lg-4 row-cols-1 g-0">--}}
{{--                                <div class="col">--}}
{{--                                    <div>--}}
{{--                                        <div>--}}
{{--                                            <div class="dropdown-header">Blog</div>--}}
{{--                                            <a class="dropdown-item" href="https://block.codescandy.com/blog-list-view.html">List View</a>--}}
{{--                                            <a class="dropdown-item" href="https://block.codescandy.com/blog.html">Grid View</a>--}}
{{--                                            <a class="dropdown-item" href="https://block.codescandy.com/blog-grid-thumbnail.html">Grid View v.2</a>--}}
{{--                                            <a class="dropdown-item" href="https://block.codescandy.com/blog-sidebar.html">Sidebar</a>--}}
{{--                                            <a class="dropdown-item" href="https://block.codescandy.com/blog-category.html">Category</a>--}}
{{--                                            <a class="dropdown-item" href="https://block.codescandy.com/blog-single.html">Single Post</a>--}}
{{--                                        </div>--}}
{{--                                        <div class="mt-3">--}}
{{--                                            <div class="dropdown-header">About</div>--}}
{{--                                            <a class="dropdown-item" href="https://block.codescandy.com/about.html">About v.1</a>--}}
{{--                                            <a class="dropdown-item" href="https://block.codescandy.com/about-v2.html">About v.2</a>--}}
{{--                                        </div>--}}
{{--                                    </div>--}}
{{--                                </div>--}}
{{--                                <div class="col">--}}
{{--                                    <div class="mt-3 mt-lg-0">--}}
{{--                                        <div>--}}
{{--                                            <div class="dropdown-header">Service</div>--}}
{{--                                            <a class="dropdown-item" href="https://block.codescandy.com/service-v1.html">Service v.1</a>--}}
{{--                                            <a class="dropdown-item" href="https://block.codescandy.com/service-v2.html">Service v.2</a>--}}
{{--                                            <a class="dropdown-item" href="https://block.codescandy.com/service-v3.html">Service v.3</a>--}}
{{--                                        </div>--}}
{{--                                        <div class="mt-3">--}}
{{--                                            <div class="dropdown-header">Events</div>--}}

{{--                                            <a class="dropdown-item" href="https://block.codescandy.com/events.html">List</a>--}}
{{--                                            <a class="dropdown-item" href="https://block.codescandy.com/event-single.html">Single</a>--}}
{{--                                        </div>--}}
{{--                                        <div class="mt-3">--}}
{{--                                            <div class="dropdown-header">Contact</div>--}}

{{--                                            <a class="dropdown-item" href="https://block.codescandy.com/contact-1.html">Contact Us</a>--}}
{{--                                            <a class="dropdown-item" href="https://block.codescandy.com/contact-2.html">Contact Sales</a>--}}
{{--                                        </div>--}}
{{--                                    </div>--}}
{{--                                </div>--}}
{{--                                <div class="col">--}}
{{--                                    <div class="mt-3 mt-lg-0">--}}
{{--                                        <div>--}}
{{--                                            <div class="dropdown-header">Portfolio</div>--}}

{{--                                            <a class="dropdown-item" href="https://block.codescandy.com/portfolio.html">Grid View</a>--}}

{{--                                            <a class="dropdown-item" href="https://block.codescandy.com/portfolio-single.html">Single View</a>--}}
{{--                                        </div>--}}
{{--                                        <div class="mt-3">--}}
{{--                                            <div class="dropdown-header">Pricing</div>--}}
{{--                                            <a class="dropdown-item" href="https://block.codescandy.com/pricing-v1.html">Pricing v.1</a>--}}
{{--                                            <a class="dropdown-item" href="https://block.codescandy.com/pricing-v2.html">Pricing v.2</a>--}}
{{--                                        </div>--}}
{{--                                        <div class="mt-3">--}}
{{--                                            <div class="dropdown-header">Career</div>--}}
{{--                                            <a class="dropdown-item" href="https://block.codescandy.com/career.html">Career</a>--}}
{{--                                        </div>--}}
{{--                                    </div>--}}
{{--                                </div>--}}
{{--                                <div class="col">--}}
{{--                                    <div class="mt-3 mt-lg-0">--}}
{{--                                        <div>--}}
{{--                                            <div class="dropdown-header">Integration</div>--}}
{{--                                            <a class="dropdown-item" href="https://block.codescandy.com/integration.html">Grid View</a>--}}
{{--                                            <a class="dropdown-item" href="https://block.codescandy.com/integration-single.html">Single</a>--}}
{{--                                        </div>--}}
{{--                                    </div>--}}
{{--                                </div>--}}
{{--                            </div>--}}
{{--                        </div>--}}
{{--                    </li>--}}
{{--                    <li class="nav-item dropdown dropdown-fullwidth">--}}
{{--                        <a class="nav-link dropdown-toggle" href="https://block.codescandy.com/landing-finance.html#" role="button" data-bs-toggle="dropdown" aria-expanded="false">Blocks</a>--}}
{{--                        <div class="dropdown-menu p-4">--}}
{{--                            <div class="row row-cols-xl-6 row-cols-lg-5 row-cols-1 gx-lg-4">--}}
{{--                                <div class="col">--}}
{{--                                    <a class="dropdown-item d-block px-0 mb-lg-3" href="https://block.codescandy.com/blocks/hero.html">--}}
{{--                                        <div class="rounded d-none d-lg-block mb-lg-2">--}}
{{--                                            <img class="w-100 rounded-2" src="{{ asset('img/hero-snippets-bootstrap.svg') }}" alt="">--}}
{{--                                        </div>--}}
{{--                                        <span>Hero</span>--}}
{{--                                    </a>--}}
{{--                                </div>--}}
{{--                                <div class="col">--}}
{{--                                    <a class="dropdown-item d-block px-0 mb-lg-3" href="https://block.codescandy.com/blocks/navbar.html">--}}
{{--                                        <div class="rounded d-none d-lg-block mb-lg-2">--}}
{{--                                            <img class="w-100 rounded-2" src="{{ asset('img/header-snippets-bootstrap.svg') }}" alt="">--}}
{{--                                        </div>--}}
{{--                                        <span>Navbar</span>--}}
{{--                                    </a>--}}
{{--                                </div>--}}
{{--                                <div class="col">--}}
{{--                                    <a class="dropdown-item d-block px-0 mb-lg-3" href="https://block.codescandy.com/blocks/about.html">--}}
{{--                                        <div class="rounded d-none d-lg-block mb-lg-2">--}}
{{--                                            <img class="w-100 rounded-2" src="{{ asset('img/about-snippets-bootstrap.svg') }}" alt="">--}}
{{--                                        </div>--}}
{{--                                        <span>About</span>--}}
{{--                                    </a>--}}
{{--                                </div>--}}
{{--                                <div class="col">--}}
{{--                                    <a class="dropdown-item d-block px-0 mb-lg-3" href="https://block.codescandy.com/blocks/blog.html">--}}
{{--                                        <div class="rounded d-none d-lg-block mb-lg-2">--}}
{{--                                            <img class="w-100 rounded-2" src="{{ asset('img/blog-snippets-bootstrap.svg') }}" alt="">--}}
{{--                                        </div>--}}
{{--                                        <span>Blog</span>--}}
{{--                                    </a>--}}
{{--                                </div>--}}
{{--                                <div class="col">--}}
{{--                                    <a class="dropdown-item d-block px-0 mb-lg-3" href="https://block.codescandy.com/blocks/carousel.html">--}}
{{--                                        <div class="rounded d-none d-lg-block mb-lg-2">--}}
{{--                                            <img class="w-100 rounded-2" src="{{ asset('img/carousel-snippets-bootstrap.svg') }}" alt="">--}}
{{--                                        </div>--}}
{{--                                        <span>Carousel</span>--}}
{{--                                    </a>--}}
{{--                                </div>--}}
{{--                                <div class="col">--}}
{{--                                    <a class="dropdown-item d-block px-0 mb-lg-3" href="https://block.codescandy.com/blocks/cta.html">--}}
{{--                                        <div class="rounded d-none d-lg-block mb-lg-2">--}}
{{--                                            <img class="w-100 rounded-2" src="{{ asset('img/call-to-action-snippets-bootstrap.svg') }}" alt="">--}}
{{--                                        </div>--}}
{{--                                        <span>Call to Action</span>--}}
{{--                                    </a>--}}
{{--                                </div>--}}
{{--                                <div class="col">--}}
{{--                                    <a class="dropdown-item d-block px-0 mb-lg-3" href="https://block.codescandy.com/blocks/clients.html">--}}
{{--                                        <div class="rounded d-none d-lg-block mb-lg-2">--}}
{{--                                            <img class="w-100 rounded-2" src="{{ asset('img/clients-logo-snippets-bootstrap.svg') }}" alt="">--}}
{{--                                        </div>--}}
{{--                                        <span>Client</span>--}}
{{--                                    </a>--}}
{{--                                </div>--}}
{{--                                <div class="col">--}}
{{--                                    <a class="dropdown-item d-block px-0 mb-lg-3" href="https://block.codescandy.com/blocks/contact.html">--}}
{{--                                        <div class="rounded d-none d-lg-block mb-lg-2">--}}
{{--                                            <img class="w-100 rounded-2" src="{{ asset('img/contact-section-example.svg') }}" alt="">--}}
{{--                                        </div>--}}
{{--                                        <span>Contact</span>--}}
{{--                                    </a>--}}
{{--                                </div>--}}
{{--                                <div class="col">--}}
{{--                                    <a class="dropdown-item d-block px-0 mb-lg-3" href="https://block.codescandy.com/blocks/form.html">--}}
{{--                                        <div class="rounded d-none d-lg-block mb-lg-2"><img class="w-100 rounded-2" src="{{ asset('img/form-snippets-bootstrap.svg') }}" alt=""></div>--}}
{{--                                        <span>Form</span>--}}
{{--                                    </a>--}}
{{--                                </div>--}}
{{--                                <div class="col">--}}
{{--                                    <a class="dropdown-item d-block px-0 mb-lg-3" href="https://block.codescandy.com/blocks/faq.html">--}}
{{--                                        <div class="rounded d-none d-lg-block mb-lg-2"><img class="w-100 rounded-2" src="{{ asset('img/faq-section-example.svg') }}" alt=""></div>--}}
{{--                                        <span>FAQ</span>--}}
{{--                                    </a>--}}
{{--                                </div>--}}
{{--                                <div class="col">--}}
{{--                                    <a class="dropdown-item d-block px-0 mb-lg-3" href="https://block.codescandy.com/blocks/team.html">--}}
{{--                                        <div class="rounded d-none d-lg-block mb-lg-2"><img class="w-100 rounded-2" src="{{ asset('img/team-snippets-bootstrap.svg') }}" alt=""></div>--}}
{{--                                        <span>Team</span>--}}
{{--                                    </a>--}}
{{--                                </div>--}}
{{--                                <div class="col">--}}
{{--                                    <a class="dropdown-item d-block px-0 mb-lg-3" href="https://block.codescandy.com/blocks/footer.html">--}}
{{--                                        <div class="rounded d-none d-lg-block mb-lg-2">--}}
{{--                                            <img class="w-100 rounded-2" src="{{ asset('img/footer-snippets-bootstrap.svg') }}" alt="">--}}
{{--                                        </div>--}}
{{--                                        <span>Footer</span>--}}
{{--                                    </a>--}}
{{--                                </div>--}}
{{--                                <div class="col">--}}
{{--                                    <a class="dropdown-item d-block px-0 mb-lg-3" href="https://block.codescandy.com/blocks/features.html">--}}
{{--                                        <div class="rounded d-none d-lg-block mb-lg-2">--}}
{{--                                            <img class="w-100 rounded-2" src="{{ asset('img/feature-snippets-bootstrap.svg') }}" alt="">--}}
{{--                                        </div>--}}
{{--                                        <span>Features</span>--}}
{{--                                    </a>--}}
{{--                                </div>--}}
{{--                                <div class="col">--}}
{{--                                    <a class="dropdown-item d-block px-0 mb-lg-3" href="https://block.codescandy.com/blocks/integration.html">--}}
{{--                                        <div class="rounded d-none d-lg-block mb-lg-2">--}}
{{--                                            <img class="w-100 rounded-2" src="{{ asset('img/integration-snippets-bootstrap.svg') }}" alt="">--}}
{{--                                        </div>--}}
{{--                                        <span>Integration</span>--}}
{{--                                    </a>--}}
{{--                                </div>--}}
{{--                                <div class="col">--}}
{{--                                    <a class="dropdown-item d-block px-0 mb-lg-3" href="https://block.codescandy.com/blocks/location.html">--}}
{{--                                        <div class="rounded d-none d-lg-block mb-lg-2">--}}
{{--                                            <img class="w-100 rounded-2" src="{{ asset('img/location-snippets-bootstrap.svg') }}" alt="">--}}
{{--                                        </div>--}}
{{--                                        <span>Location</span>--}}
{{--                                    </a>--}}
{{--                                </div>--}}
{{--                                <div class="col">--}}
{{--                                    <a class="dropdown-item d-block px-0 mb-lg-3" href="https://block.codescandy.com/blocks/portfolio.html">--}}
{{--                                        <div class="rounded d-none d-lg-block mb-lg-2">--}}
{{--                                            <img class="w-100 rounded-2" src="{{ asset('img/portfolio-snippets-bootstrap.svg') }}" alt="">--}}
{{--                                        </div>--}}
{{--                                        <span>Portfolio</span>--}}
{{--                                    </a>--}}
{{--                                </div>--}}
{{--                                <div class="col">--}}
{{--                                    <a class="dropdown-item d-block px-0 mb-lg-3" href="https://block.codescandy.com/blocks/process.html">--}}
{{--                                        <div class="rounded d-none d-lg-block mb-lg-2">--}}
{{--                                            <img class="w-100 rounded-2" src="{{ asset('img/process-snippets-bootstrap.svg') }}" alt="">--}}
{{--                                        </div>--}}
{{--                                        <span>Process</span>--}}
{{--                                    </a>--}}
{{--                                </div>--}}
{{--                                <div class="col">--}}
{{--                                    <a class="dropdown-item d-block px-0 mb-lg-3" href="https://block.codescandy.com/blocks/pricing.html">--}}
{{--                                        <div class="rounded d-none d-lg-block mb-lg-2 bg-gray-200">--}}
{{--                                            <img class="w-100 rounded-2" src="{{ asset('img/pricing-snippets-bootstrap.svg') }}" alt="">--}}
{{--                                        </div>--}}
{{--                                        <span>Pricing</span>--}}
{{--                                    </a>--}}
{{--                                </div>--}}

{{--                                <div class="col">--}}
{{--                                    <a class="dropdown-item d-block px-0 mb-lg-3" href="https://block.codescandy.com/blocks/facts.html">--}}
{{--                                        <div class="rounded d-none d-lg-block mb-lg-2">--}}
{{--                                            <img class="w-100 rounded-2" src="{{ asset('img/stats-snippets-bootstrap.svg') }}" alt="">--}}
{{--                                        </div>--}}
{{--                                        <span>Stats</span>--}}
{{--                                    </a>--}}
{{--                                </div>--}}
{{--                                <div class="col">--}}
{{--                                    <a class="dropdown-item d-block px-0 mb-lg-3" href="https://block.codescandy.com/blocks/testimonails.html">--}}
{{--                                        <div class="rounded d-none d-lg-block mb-lg-2">--}}
{{--                                            <img class="w-100 rounded-2" src="{{ asset('img/testimonial-snippets-bootstrap.svg') }}" alt="">--}}
{{--                                        </div>--}}
{{--                                        <span>Testimonials</span>--}}
{{--                                    </a>--}}
{{--                                </div>--}}
{{--                            </div>--}}
{{--                        </div>--}}
{{--                    </li>--}}
{{--                    <li class="nav-item dropdown">--}}
{{--                        <a class="nav-link dropdown-toggle" href="https://block.codescandy.com/landing-finance.html#" role="button" data-bs-toggle="dropdown" aria-expanded="false">Accounts</a>--}}
{{--                        <ul class="dropdown-menu">--}}
{{--                            <li><a class="dropdown-item" href="https://block.codescandy.com/account-profile.html">Profile</a></li>--}}
{{--                            <li><a class="dropdown-item" href="https://block.codescandy.com/account-security.html">Security</a></li>--}}
{{--                            <li><a class="dropdown-item" href="https://block.codescandy.com/account-billing.html">Billing</a></li>--}}
{{--                            <li><a class="dropdown-item" href="https://block.codescandy.com/account-team.html">Team</a></li>--}}
{{--                            <li><a class="dropdown-item" href="https://block.codescandy.com/account-notification.html">Notifications</a></li>--}}
{{--                            <li><a class="dropdown-item" href="https://block.codescandy.com/account-app-integration.html">Integration</a></li>--}}
{{--                            <li><a class="dropdown-item" href="https://block.codescandy.com/account-device-session.html">Session</a></li>--}}
{{--                            <li><a class="dropdown-item" href="https://block.codescandy.com/account-social-links.html">Social</a></li>--}}
{{--                            <li><a class="dropdown-item" href="https://block.codescandy.com/account-appearance.html">Appearance</a></li>--}}
{{--                            <li class="dropdown-submenu dropend">--}}
{{--                                <a class="dropdown-item dropdown-toggle" href="https://block.codescandy.com/landing-finance.html#">Authentication</a>--}}
{{--                                <ul class="dropdown-menu">--}}
{{--                                    <li class="dropdown-header">Simple</li>--}}

{{--                                    <li>--}}
{{--                                        <a class="dropdown-item" href="https://block.codescandy.com/signin.html">Sign In</a>--}}
{{--                                    </li>--}}
{{--                                    <li>--}}
{{--                                        <a class="dropdown-item" href="https://block.codescandy.com/signup.html">Sign Up</a>--}}
{{--                                    </li>--}}
{{--                                    <li>--}}
{{--                                        <a class="dropdown-item" href="https://block.codescandy.com/forget-password.html">Forget Password</a>--}}
{{--                                    </li>--}}
{{--                                    <li>--}}
{{--                                        <a class="dropdown-item" href="https://block.codescandy.com/reset-password.html">Reset Password</a>--}}
{{--                                    </li>--}}
{{--                                    <li>--}}
{{--                                        <a class="dropdown-item" href="https://block.codescandy.com/otp-varification.html">OTP Varification</a>--}}
{{--                                    </li>--}}
{{--                                    <li><hr class="dropdown-divider"></li>--}}
{{--                                    <li class="dropdown-header">Side Cover</li>--}}

{{--                                    <li>--}}
{{--                                        <a class="dropdown-item" href="https://block.codescandy.com/signin-v2.html">Sign In</a>--}}
{{--                                    </li>--}}

{{--                                    <li>--}}
{{--                                        <a class="dropdown-item" href="https://block.codescandy.com/signup-v2.html">Sign Up</a>--}}
{{--                                    </li>--}}

{{--                                    <li>--}}
{{--                                        <a class="dropdown-item" href="https://block.codescandy.com/forget-password-v2.html">Forget Password</a>--}}
{{--                                    </li>--}}
{{--                                    <li>--}}
{{--                                        <a class="dropdown-item" href="https://block.codescandy.com/reset-password-v2.html">Reset Password</a>--}}
{{--                                    </li>--}}
{{--                                    <li>--}}
{{--                                        <a class="dropdown-item" href="https://block.codescandy.com/otp-varification-v2.html">OTP Varification</a>--}}
{{--                                    </li>--}}
{{--                                </ul>--}}
{{--                            </li>--}}
{{--                            <li class="dropdown-submenu dropend">--}}
{{--                                <a class="dropdown-item dropdown-toggle" href="https://block.codescandy.com/landing-finance.html#">Utility</a>--}}
{{--                                <ul class="dropdown-menu">--}}
{{--                                    <li>--}}
{{--                                        <a class="dropdown-item" href="https://block.codescandy.com/404-error.html">404 Error</a>--}}
{{--                                    </li>--}}
{{--                                    <li>--}}
{{--                                        <a class="dropdown-item" href="https://block.codescandy.com/changelog.html">Changelog</a>--}}
{{--                                    </li>--}}
{{--                                </ul>--}}
{{--                            </li>--}}
{{--                        </ul>--}}
{{--                    </li>--}}
{{--                    <li class="nav-item dropdown">--}}
{{--                        <a class="nav-link dropdown-toggle" href="https://block.codescandy.com/landing-finance.html#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Docs</a>--}}
{{--                        <div class="dropdown-menu dropdown-menu-md" aria-labelledby="navbarDropdown">--}}
{{--                            <a class="dropdown-item mb-3 text-body" href="https://block.codescandy.com/docs/index.html">--}}
{{--                                <div class="d-flex align-items-center">--}}
{{--                                    <i class="bi bi-file-text fs-4 text-primary"></i>--}}
{{--                                    <div class="ms-3 lh-1">--}}
{{--                                        <h5 class="mb-1">Documentations</h5>--}}
{{--                                        <p class="mb-0 fs-6">Browse the all documentation</p>--}}
{{--                                    </div>--}}
{{--                                </div>--}}
{{--                            </a>--}}

{{--                            <a class="dropdown-item text-body" href="https://block.codescandy.com/docs/changelog.html">--}}
{{--                                <div class="d-flex align-items-center">--}}
{{--                                    <i class="bi bi-clipboard fs-4 text-primary"></i>--}}
{{--                                    <div class="ms-3 lh-1">--}}
{{--                                        <h5 class="mb-1">--}}
{{--                                            Changelog--}}
{{--                                            <span class="text-primary ms-1" id="changelog"></span>--}}
{{--                                        </h5>--}}
{{--                                        <p class="mb-0 fs-6">See what's new</p>--}}
{{--                                    </div>--}}
{{--                                </div>--}}
{{--                            </a>--}}
{{--                        </div>--}}
{{--                    </li>--}}
{{--                </ul>--}}
{{--                <div class="mt-3 mt-lg-0 d-flex align-items-center">--}}
{{--                    <a href="https://block.codescandy.com/signin.html" class="btn btn-light mx-2">Login</a>--}}
{{--                    <a href="https://block.codescandy.com/signup.html" class="btn btn-primary">Create account</a>--}}
{{--                </div>--}}
{{--            </div>--}}
{{--        </div>--}}
{{--    </div>--}}
{{--</nav>--}}

<header>
    <nav class="navbar navbar-expand-lg transparent navbar-transparent navbar-dark">
        <div class="container px-3">
            <a class="navbar-brand" href="#">
                <img src="{{ asset('img/xfera/xferatech_name.png') }}" alt="Logo" style="width: 120px;">
            </a>
            <button class="navbar-toggler offcanvas-nav-btn" type="button">
                <i class="bi bi-list"></i>
            </button>
            <div class="offcanvas offcanvas-start offcanvas-nav" style="width: 20rem">
                <div class="offcanvas-header">
                    <a href="https://block.codescandy.com/index.html" class="text-inverse"><img src="{{ asset('img/logo.svg') }}" alt=""></a>
                    <button type="button" class="btn-close" data-bs-dismiss="offcanvas" aria-label="Close"></button>
                </div>
                <div class="offcanvas-body pt-0 align-items-center">
                    <ul class="navbar-nav mx-auto align-items-lg-center">
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" href="https://block.codescandy.com/landing-finance.html#" role="button" data-bs-toggle="dropdown" aria-expanded="false">Landings</a>
                            <ul class="dropdown-menu">
                                <li><a class="dropdown-item" href="https://block.codescandy.com/index.html">Landing Overview</a></li>
                                <li><a class="dropdown-item" href="https://block.codescandy.com/landing-sass-v1.html">Saas v.1</a></li>
                                <li><a class="dropdown-item" href="https://block.codescandy.com/landing-sass-v2.html">Sass v.2</a></li>
                                <li><a class="dropdown-item" href="https://block.codescandy.com/landing-accounting.html">Accounting</a></li>
                                <li><a class="dropdown-item" href="https://block.codescandy.com/landing-finance.html">Finance</a></li>
                                <li><a class="dropdown-item" href="https://block.codescandy.com/landing-jamstack-agancy.html">Jamstack Agency</a></li>
                                <li><a class="dropdown-item" href="https://block.codescandy.com/landing-conference.html">Conference</a></li>
                                <li><a class="dropdown-item" href="https://block.codescandy.com/landing-personal.html">Personal</a></li>
                            </ul>
                        </li>
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" href="https://block.codescandy.com/landing-finance.html#" role="button" data-bs-toggle="dropdown" aria-expanded="false">Pages</a>
                            <div class="dropdown-menu dropdown-menu-xxl">
                                <div class="row row-cols-lg-4 row-cols-1 g-0">
                                    <div class="col">
                                        <div>
                                            <div>
                                                <div class="dropdown-header">Blog</div>
                                                <a class="dropdown-item" href="https://block.codescandy.com/blog-list-view.html">List View</a>
                                                <a class="dropdown-item" href="https://block.codescandy.com/blog.html">Grid View</a>
                                                <a class="dropdown-item" href="https://block.codescandy.com/blog-grid-thumbnail.html">Grid View v.2</a>
                                                <a class="dropdown-item" href="https://block.codescandy.com/blog-sidebar.html">Sidebar</a>
                                                <a class="dropdown-item" href="https://block.codescandy.com/blog-category.html">Category</a>
                                                <a class="dropdown-item" href="https://block.codescandy.com/blog-single.html">Single Post</a>
                                            </div>
                                            <div class="mt-3">
                                                <div class="dropdown-header">About</div>
                                                <a class="dropdown-item" href="https://block.codescandy.com/about.html">About v.1</a>
                                                <a class="dropdown-item" href="https://block.codescandy.com/about-v2.html">About v.2</a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col">
                                        <div class="mt-3 mt-lg-0">
                                            <div>
                                                <div class="dropdown-header">Service</div>
                                                <a class="dropdown-item" href="https://block.codescandy.com/service-v1.html">Service v.1</a>
                                                <a class="dropdown-item" href="https://block.codescandy.com/service-v2.html">Service v.2</a>
                                                <a class="dropdown-item" href="https://block.codescandy.com/service-v3.html">Service v.3</a>
                                            </div>
                                            <div class="mt-3">
                                                <div class="dropdown-header">Events</div>

                                                <a class="dropdown-item" href="https://block.codescandy.com/events.html">List</a>
                                                <a class="dropdown-item" href="https://block.codescandy.com/event-single.html">Single</a>
                                            </div>
                                            <div class="mt-3">
                                                <div class="dropdown-header">Contact</div>

                                                <a class="dropdown-item" href="https://block.codescandy.com/contact-1.html">Contact Us</a>
                                                <a class="dropdown-item" href="https://block.codescandy.com/contact-2.html">Contact Sales</a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col">
                                        <div class="mt-3 mt-lg-0">
                                            <div>
                                                <div class="dropdown-header">Portfolio</div>

                                                <a class="dropdown-item" href="https://block.codescandy.com/portfolio.html">Grid View</a>

                                                <a class="dropdown-item" href="https://block.codescandy.com/portfolio-single.html">Single View</a>
                                            </div>
                                            <div class="mt-3">
                                                <div class="dropdown-header">Pricing</div>
                                                <a class="dropdown-item" href="https://block.codescandy.com/pricing-v1.html">Pricing v.1</a>
                                                <a class="dropdown-item" href="https://block.codescandy.com/pricing-v2.html">Pricing v.2</a>
                                            </div>
                                            <div class="mt-3">
                                                <div class="dropdown-header">Career</div>
                                                <a class="dropdown-item" href="https://block.codescandy.com/career.html">Career</a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col">
                                        <div class="mt-3 mt-lg-0">
                                            <div>
                                                <div class="dropdown-header">Integration</div>
                                                <a class="dropdown-item" href="https://block.codescandy.com/integration.html">Grid View</a>
                                                <a class="dropdown-item" href="https://block.codescandy.com/integration-single.html">Single</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </li>
                        <li class="nav-item dropdown dropdown-fullwidth">
                            <a class="nav-link dropdown-toggle" href="https://block.codescandy.com/landing-finance.html#" role="button" data-bs-toggle="dropdown" aria-expanded="false">Blocks</a>
                            <div class="dropdown-menu p-4">
                                <div class="row row-cols-xl-6 row-cols-lg-5 row-cols-1 gx-lg-4">
                                    <div class="col">
                                        <a class="dropdown-item d-block px-0 mb-lg-3" href="https://block.codescandy.com/blocks/hero.html">
                                            <div class="rounded d-none d-lg-block mb-lg-2">
                                                <img class="w-100 rounded-2" src="{{ asset('img/hero-snippets-bootstrap.svg') }}" alt="">
                                            </div>
                                            <span>Hero</span>
                                        </a>
                                    </div>
                                    <div class="col">
                                        <a class="dropdown-item d-block px-0 mb-lg-3" href="https://block.codescandy.com/blocks/navbar.html">
                                            <div class="rounded d-none d-lg-block mb-lg-2">
                                                <img class="w-100 rounded-2" src="{{ asset('img/header-snippets-bootstrap.svg') }}" alt="">
                                            </div>
                                            <span>Navbar</span>
                                        </a>
                                    </div>
                                    <div class="col">
                                        <a class="dropdown-item d-block px-0 mb-lg-3" href="https://block.codescandy.com/blocks/about.html">
                                            <div class="rounded d-none d-lg-block mb-lg-2">
                                                <img class="w-100 rounded-2" src="{{ asset('img/about-snippets-bootstrap.svg') }}" alt="">
                                            </div>
                                            <span>About</span>
                                        </a>
                                    </div>
                                    <div class="col">
                                        <a class="dropdown-item d-block px-0 mb-lg-3" href="https://block.codescandy.com/blocks/blog.html">
                                            <div class="rounded d-none d-lg-block mb-lg-2">
                                                <img class="w-100 rounded-2" src="{{ asset('img/blog-snippets-bootstrap.svg') }}" alt="">
                                            </div>
                                            <span>Blog</span>
                                        </a>
                                    </div>
                                    <div class="col">
                                        <a class="dropdown-item d-block px-0 mb-lg-3" href="https://block.codescandy.com/blocks/carousel.html">
                                            <div class="rounded d-none d-lg-block mb-lg-2">
                                                <img class="w-100 rounded-2" src="{{ asset('img/carousel-snippets-bootstrap.svg') }}" alt="">
                                            </div>
                                            <span>Carousel</span>
                                        </a>
                                    </div>
                                    <div class="col">
                                        <a class="dropdown-item d-block px-0 mb-lg-3" href="https://block.codescandy.com/blocks/cta.html">
                                            <div class="rounded d-none d-lg-block mb-lg-2">
                                                <img class="w-100 rounded-2" src="{{ asset('img/call-to-action-snippets-bootstrap.svg') }}" alt="">
                                            </div>
                                            <span>Call to Action</span>
                                        </a>
                                    </div>
                                    <div class="col">
                                        <a class="dropdown-item d-block px-0 mb-lg-3" href="https://block.codescandy.com/blocks/clients.html">
                                            <div class="rounded d-none d-lg-block mb-lg-2">
                                                <img class="w-100 rounded-2" src="{{ asset('img/clients-logo-snippets-bootstrap.svg') }}" alt="">
                                            </div>
                                            <span>Client</span>
                                        </a>
                                    </div>
                                    <div class="col">
                                        <a class="dropdown-item d-block px-0 mb-lg-3" href="https://block.codescandy.com/blocks/contact.html">
                                            <div class="rounded d-none d-lg-block mb-lg-2">
                                                <img class="w-100 rounded-2" src="{{ asset('img/contact-section-example.svg') }}" alt="">
                                            </div>
                                            <span>Contact</span>
                                        </a>
                                    </div>
                                    <div class="col">
                                        <a class="dropdown-item d-block px-0 mb-lg-3" href="https://block.codescandy.com/blocks/form.html">
                                            <div class="rounded d-none d-lg-block mb-lg-2"><img class="w-100 rounded-2" src="{{ asset('img/form-snippets-bootstrap.svg') }}" alt=""></div>
                                            <span>Form</span>
                                        </a>
                                    </div>
                                    <div class="col">
                                        <a class="dropdown-item d-block px-0 mb-lg-3" href="https://block.codescandy.com/blocks/faq.html">
                                            <div class="rounded d-none d-lg-block mb-lg-2"><img class="w-100 rounded-2" src="{{ asset('img/faq-section-example.svg') }}" alt=""></div>
                                            <span>FAQ</span>
                                        </a>
                                    </div>
                                    <div class="col">
                                        <a class="dropdown-item d-block px-0 mb-lg-3" href="https://block.codescandy.com/blocks/team.html">
                                            <div class="rounded d-none d-lg-block mb-lg-2"><img class="w-100 rounded-2" src="{{ asset('img/team-snippets-bootstrap.svg') }}" alt=""></div>
                                            <span>Team</span>
                                        </a>
                                    </div>
                                    <div class="col">
                                        <a class="dropdown-item d-block px-0 mb-lg-3" href="https://block.codescandy.com/blocks/footer.html">
                                            <div class="rounded d-none d-lg-block mb-lg-2">
                                                <img class="w-100 rounded-2" src="{{ asset('img/footer-snippets-bootstrap.svg') }}" alt="">
                                            </div>
                                            <span>Footer</span>
                                        </a>
                                    </div>
                                    <div class="col">
                                        <a class="dropdown-item d-block px-0 mb-lg-3" href="https://block.codescandy.com/blocks/features.html">
                                            <div class="rounded d-none d-lg-block mb-lg-2">
                                                <img class="w-100 rounded-2" src="{{ asset('img/feature-snippets-bootstrap.svg') }}" alt="">
                                            </div>
                                            <span>Features</span>
                                        </a>
                                    </div>
                                    <div class="col">
                                        <a class="dropdown-item d-block px-0 mb-lg-3" href="https://block.codescandy.com/blocks/integration.html">
                                            <div class="rounded d-none d-lg-block mb-lg-2">
                                                <img class="w-100 rounded-2" src="{{ asset('img/integration-snippets-bootstrap.svg') }}" alt="">
                                            </div>
                                            <span>Integration</span>
                                        </a>
                                    </div>
                                    <div class="col">
                                        <a class="dropdown-item d-block px-0 mb-lg-3" href="https://block.codescandy.com/blocks/location.html">
                                            <div class="rounded d-none d-lg-block mb-lg-2">
                                                <img class="w-100 rounded-2" src="{{ asset('img/location-snippets-bootstrap.svg') }}" alt="">
                                            </div>
                                            <span>Location</span>
                                        </a>
                                    </div>
                                    <div class="col">
                                        <a class="dropdown-item d-block px-0 mb-lg-3" href="https://block.codescandy.com/blocks/portfolio.html">
                                            <div class="rounded d-none d-lg-block mb-lg-2">
                                                <img class="w-100 rounded-2" src="{{ asset('img/portfolio-snippets-bootstrap.svg') }}" alt="">
                                            </div>
                                            <span>Portfolio</span>
                                        </a>
                                    </div>
                                    <div class="col">
                                        <a class="dropdown-item d-block px-0 mb-lg-3" href="https://block.codescandy.com/blocks/process.html">
                                            <div class="rounded d-none d-lg-block mb-lg-2">
                                                <img class="w-100 rounded-2" src="{{ asset('img/process-snippets-bootstrap.svg') }}" alt="">
                                            </div>
                                            <span>Process</span>
                                        </a>
                                    </div>
                                    <div class="col">
                                        <a class="dropdown-item d-block px-0 mb-lg-3" href="https://block.codescandy.com/blocks/pricing.html">
                                            <div class="rounded d-none d-lg-block mb-lg-2 bg-gray-200">
                                                <img class="w-100 rounded-2" src="{{ asset('img/pricing-snippets-bootstrap.svg') }}" alt="">
                                            </div>
                                            <span>Pricing</span>
                                        </a>
                                    </div>

                                    <div class="col">
                                        <a class="dropdown-item d-block px-0 mb-lg-3" href="https://block.codescandy.com/blocks/facts.html">
                                            <div class="rounded d-none d-lg-block mb-lg-2">
                                                <img class="w-100 rounded-2" src="{{ asset('img/stats-snippets-bootstrap.svg') }}" alt="">
                                            </div>
                                            <span>Stats</span>
                                        </a>
                                    </div>
                                    <div class="col">
                                        <a class="dropdown-item d-block px-0 mb-lg-3" href="https://block.codescandy.com/blocks/testimonails.html">
                                            <div class="rounded d-none d-lg-block mb-lg-2">
                                                <img class="w-100 rounded-2" src="{{ asset('img/testimonial-snippets-bootstrap.svg') }}" alt="">
                                            </div>
                                            <span>Testimonials</span>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </li>
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" href="https://block.codescandy.com/landing-finance.html#" role="button" data-bs-toggle="dropdown" aria-expanded="false">Accounts</a>
                            <ul class="dropdown-menu">
                                <li><a class="dropdown-item" href="https://block.codescandy.com/account-profile.html">Profile</a></li>
                                <li><a class="dropdown-item" href="https://block.codescandy.com/account-security.html">Security</a></li>
                                <li><a class="dropdown-item" href="https://block.codescandy.com/account-billing.html">Billing</a></li>
                                <li><a class="dropdown-item" href="https://block.codescandy.com/account-team.html">Team</a></li>
                                <li><a class="dropdown-item" href="https://block.codescandy.com/account-notification.html">Notifications</a></li>
                                <li><a class="dropdown-item" href="https://block.codescandy.com/account-app-integration.html">Integration</a></li>
                                <li><a class="dropdown-item" href="https://block.codescandy.com/account-device-session.html">Session</a></li>
                                <li><a class="dropdown-item" href="https://block.codescandy.com/account-social-links.html">Social</a></li>
                                <li><a class="dropdown-item" href="https://block.codescandy.com/account-appearance.html">Appearance</a></li>
                                <li class="dropdown-submenu dropend">
                                    <a class="dropdown-item dropdown-toggle" href="https://block.codescandy.com/landing-finance.html#">Authentication</a>
                                    <ul class="dropdown-menu">
                                        <li class="dropdown-header">Simple</li>

                                        <li>
                                            <a class="dropdown-item" href="https://block.codescandy.com/signin.html">Sign In</a>
                                        </li>
                                        <li>
                                            <a class="dropdown-item" href="https://block.codescandy.com/signup.html">Sign Up</a>
                                        </li>
                                        <li>
                                            <a class="dropdown-item" href="https://block.codescandy.com/forget-password.html">Forget Password</a>
                                        </li>
                                        <li>
                                            <a class="dropdown-item" href="https://block.codescandy.com/reset-password.html">Reset Password</a>
                                        </li>
                                        <li>
                                            <a class="dropdown-item" href="https://block.codescandy.com/otp-varification.html">OTP Varification</a>
                                        </li>
                                        <li><hr class="dropdown-divider"></li>
                                        <li class="dropdown-header">Side Cover</li>

                                        <li>
                                            <a class="dropdown-item" href="https://block.codescandy.com/signin-v2.html">Sign In</a>
                                        </li>

                                        <li>
                                            <a class="dropdown-item" href="https://block.codescandy.com/signup-v2.html">Sign Up</a>
                                        </li>

                                        <li>
                                            <a class="dropdown-item" href="https://block.codescandy.com/forget-password-v2.html">Forget Password</a>
                                        </li>
                                        <li>
                                            <a class="dropdown-item" href="https://block.codescandy.com/reset-password-v2.html">Reset Password</a>
                                        </li>
                                        <li>
                                            <a class="dropdown-item" href="https://block.codescandy.com/otp-varification-v2.html">OTP Varification</a>
                                        </li>
                                    </ul>
                                </li>
                                <li class="dropdown-submenu dropend">
                                    <a class="dropdown-item dropdown-toggle" href="https://block.codescandy.com/landing-finance.html#">Utility</a>
                                    <ul class="dropdown-menu">
                                        <li>
                                            <a class="dropdown-item" href="https://block.codescandy.com/404-error.html">404 Error</a>
                                        </li>
                                        <li>
                                            <a class="dropdown-item" href="https://block.codescandy.com/changelog.html">Changelog</a>
                                        </li>
                                    </ul>
                                </li>
                            </ul>
                        </li>
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" href="https://block.codescandy.com/landing-finance.html#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Docs</a>
                            <div class="dropdown-menu dropdown-menu-md" aria-labelledby="navbarDropdown">
                                <a class="dropdown-item mb-3 text-body" href="https://block.codescandy.com/docs/index.html">
                                    <div class="d-flex align-items-center">
                                        <i class="bi bi-file-text fs-4 text-primary"></i>
                                        <div class="ms-3 lh-1">
                                            <h5 class="mb-1">Documentations</h5>
                                            <p class="mb-0 fs-6">Browse the all documentation</p>
                                        </div>
                                    </div>
                                </a>

                                <a class="dropdown-item text-body" href="https://block.codescandy.com/docs/changelog.html">
                                    <div class="d-flex align-items-center">
                                        <i class="bi bi-clipboard fs-4 text-primary"></i>
                                        <div class="ms-3 lh-1">
                                            <h5 class="mb-1">
                                                Changelog
                                                <span class="text-primary ms-1" id="changelog"></span>
                                            </h5>
                                            <p class="mb-0 fs-6">See what's new</p>
                                        </div>
                                    </div>
                                </a>
                            </div>
                        </li>
                    </ul>
                    <div class="mt-3 mt-lg-0 d-flex align-items-center">
                        <a href="#" class="btn btn-danger">Contato</a>
                    </div>
                </div>
            </div>
        </div>
    </nav>
</header>
