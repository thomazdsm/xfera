<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8" />
    <link rel="icon" type="image/png" href="<?php echo e(asset('favicon.ico')); ?>">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
    <title><?php echo e(config('app.name')); ?></title>
    <meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0' name='viewport' />
    <meta name="viewport" content="width=device-width" />

    <link href="<?php echo e(asset('css/bootstrap.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(asset('css/landing-page.css')); ?>" rel="stylesheet"/>

    <!--     Fonts and icons     -->
    <script src="https://kit.fontawesome.com/4d3192896f.js" crossorigin="anonymous"></script>
    <link href='http://fonts.googleapis.com/css?family=Open+Sans:300italic,400,300' rel='stylesheet' type='text/css'>
    <link href="<?php echo e(asset('css/pe-icon-7-stroke.css')); ?>" rel="stylesheet" />

    <?php echo $__env->yieldContent('css'); ?>
</head>
<body class="landing-page landing-page1">
    <?php echo $__env->make('components.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="wrapper">
        <?php echo $__env->yieldContent('content'); ?>
    </div>

    <?php echo $__env->make('components.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php echo $__env->make('components.vlibras', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <script src="<?php echo e(asset('js/jquery-1.10.2.js')); ?>" type="text/javascript"></script>
    <script src="<?php echo e(asset('js/jquery-ui-1.10.4.custom.min.js')); ?>" type="text/javascript"></script>
    <script src="<?php echo e(asset('js/bootstrap.js')); ?>" type="text/javascript"></script>
    <script src="<?php echo e(asset('js/awesome-landing-page.js')); ?>" type="text/javascript"></script>

    <?php echo $__env->yieldContent('js'); ?>
</body>
</html>
<?php /**PATH /home/thomaz/Documents/XFeraTech/xfera/resources/views/layout/app.blade.php ENDPATH**/ ?>