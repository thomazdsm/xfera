<div class="parallax filter-gradient full-xfera" data-color="blue">
    <div class="parallax-background bg-xfera">

    </div>
    <div class="container teste" style="">
        <div class="row">
            <div class="col-md-12">
                <h1 class="xfera-presentation-title text-center">XFERA TECH</h1>
            </div>
            <div class="col-md-12">
                <h2 class="xfera-presentation-subtitle text-center">Soluções tecnológicas para educação e pesquisa</h2>
            </div>
        </div>
    </div>
</div>
<?php /**PATH /home/thomaz/Documents/XFeraTech/xfera/resources/views/components/home.blade.php ENDPATH**/ ?>